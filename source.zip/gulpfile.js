// including plugins
var gulp = require('gulp')
, rename = require('gulp-rename')
, minifyHtml = require("gulp-minify-html")
, minifyCss = require("gulp-minify-css")
, ngmin = require('gulp-ngmin')
, uglify = require("gulp-uglify")
, clean = require('gulp-clean')
, sass = require('gulp-sass')
, gif = require('gulp-if')
, lazypipe = require('lazypipe')
, obfuscate = require('gulp-obfuscate')
, concat = require('gulp-concat');

var path = {
    build: {
      css : './dist/assets/css',  
      js: './dist/assets/js',

    },
    src: {
      css : './source/css/*.css',  
      js: './source/js/**/*.js',
      sass: './source/sass/app.scss'
    }
};

var origen = './source',
    destino = './dist/assets',
    isProd = true; 

gulp.task('default', ['clean','sass','minify-js', 'minify-css']);

var minijs = lazypipe()
//.pipe(uglify)
//.pipe(ngmin)
//.pipe(obfuscate, { replaceMethod: obfuscate.LOOK_OF_DISAPPROVAL, exclude : ['log'] })
.pipe(rename, { extname: '.min.js' });

// task
gulp.task('minify-js', function () {
    
    gulp.src(path.src.js) // path to your files
        .pipe(gif(isProd, minijs()))    
        .pipe(gulp.dest(path.build.js));
});

var minicss = lazypipe()
.pipe(minifyCss)
.pipe(rename, { extname: '.min.css' });


gulp.task('sass', function() {
    gulp.src([path.src.sass])
        .pipe(sass().on('error', sass.logError))
        .pipe(gif(isProd, minicss()))         
        .pipe(gulp.dest(path.build.css));
});

gulp.task('minify-css', function() {
    gulp.src(path.src.css)
        .pipe(gif(isProd, minicss()))         
        .pipe(gulp.dest(path.build.css));
});

gulp.task('clean', function(){
   
   gulp.src(path.build.css+'/*')
    .pipe(clean());
   
   gulp.src(path.build.js+'/*')
    .pipe(clean());
});